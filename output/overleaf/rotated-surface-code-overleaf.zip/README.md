# Rotated Surface Codes

Upload this ZIP as a new Overleaf project. Set main.tex as the main document and choose XeLaTeX. All diagrams are editable TikZ in figures/diagrams.tex. No shell escape or external images are needed.
